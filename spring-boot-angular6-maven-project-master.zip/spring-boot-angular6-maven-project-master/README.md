# spring-boot-angular6-maven-project
Build and package spring boot and angular6 into a deployable war file

The corresponding article can be found at https://techshard.com/2018/08/12/building-a-web-app-using-spring-boot-angular-6-and-maven/ and https://dzone.com/articles/building-a-web-app-using-spring-boot-angular-6-and
